require 'puppet-openstack_spec_helper/beaker_spec_helper'
